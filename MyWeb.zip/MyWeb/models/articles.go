package models

type Article struct {
	BlogTitle   string
	BlogArticle string
	Userid      int
	ID          int
}

type ArticleList struct {
	ID      []int
	UserId  []int
	Title   []string
	Content []string
}
