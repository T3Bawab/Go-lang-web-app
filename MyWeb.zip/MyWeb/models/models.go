package models

import "time"

type User struct {
	Name        string
	Email       string
	Passwrod    string
	AcctCreated time.Time
	LastLogin   time.Time
	UserType    int
	ID          int
}

type Post struct {
	Title   string
	Content string
	UserId  int // راح نتحقق منه اول شي
	Id      int
}
