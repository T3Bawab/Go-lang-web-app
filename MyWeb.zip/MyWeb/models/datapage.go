package models

import "MyWeb/pkg/forms"

type DataPage struct {
	StrMap map[string]string
	IntMap map[string]int
	FltMap map[string]float32

	Data map[string]interface{} // here the data may be any data type like string or int

	CSRFToken string
	Warning   string // the warning message
	Error     string // the error message

	Form            *forms.Form
	IsAuthenticated int
}
