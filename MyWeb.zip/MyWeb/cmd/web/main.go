package main

import (
	"MyWeb/models"
	"MyWeb/pkg/configs"
	"MyWeb/pkg/dbdriver"
	"MyWeb/pkg/handlers"
	"MyWeb/pkg/renders"
	"encoding/gob"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/alexedwards/scs/v2"
)

var (
	AppConfig       configs.AppConfig
	sessiongManager *scs.SessionManager
)

func main() {
	db, err := run()
	if err != nil {
		log.Fatal("( ! ) Error with run func : \n", err)
	}

	defer db.SQL.Close()

	srv := &http.Server{
		Addr:    ":4000",
		Handler: routesController(&AppConfig),
	}

	fmt.Println("\033[31m" + `

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣾⣿⡟⣳⣄⣀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⡉⣿⣿⣿⣿⡿⠛⠷⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⡿⠿⢿⡟⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣧⣤⣶⣄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⠁⣴⡟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣰⣿⣿⣿⣿⣿⣿⣿⠿⠟⠋⢉⣠⣶⡟⢀⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣾⣿⡿⠿⠟⠛⠉⡉⠀⠀⠀⠀⠸⣿⠿⠃⠘⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠉⢁⣤⣤⣶⣶⣿⠟⠁⠀⠀⠀⠀⠀⢠⡄⠀⢸⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠈⠉⠉⠉⠉⠁⠀⠀⠀⠀⢀⣤⣤⣾⣧⣤⣼⣿⣤⣤⣤⣄⠀⠀⠀⠀⠀` + "\033[0m")
	fmt.Println("( ! ) The server is running on http://localhost:4000")

	err = srv.ListenAndServe()

	if err != nil {
		log.Fatal(err)
	}

}

func run() (*dbdriver.DataBase, error) {
	gob.Register(models.Article{})

	// add table models in the session
	gob.Register(models.User{})
	gob.Register(models.Post{})

	//--------------------------------------------
	sessiongManager = scs.New()

	sessiongManager.Lifetime = 24 * time.Hour
	sessiongManager.Cookie.Persist = true
	sessiongManager.Cookie.Secure = false // now in development mode we put it http after https
	sessiongManager.Cookie.SameSite = http.SameSiteLaxMode

	// save all session to config file

	AppConfig.Session = sessiongManager

	//---------------------------------------------
	db, err := dbdriver.Sql_Connect("host=localhost port=5432 dbname=blog_db user=postgres password=awab")

	if err != nil {
		log.Fatal("( ! ) Errro with connect to the dataBase :\n\n", err)
		return nil, err
	}

	repo := handlers.NewRepository(&AppConfig, db)

	handlers.NewHandlers(repo)

	renders.NewAppconfig(&AppConfig)
	return db, nil
}
