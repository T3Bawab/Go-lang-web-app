package main

import (
	"MyWeb/pkg/helpers"
	"fmt"
	"net/http"
	"time"

	"github.com/justinas/nosurf"
)

func LogRequestInfo(next http.Handler) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		date := time.Now()
		fmt.Printf("\033[36m"+
			"Date -> [%d/%d/%d] , UrlPath -> %s  , Method -> %s       \r", date.Year(), date.Month(), date.Day(), r.URL.Path, r.Method+"\033[0m")

		next.ServeHTTP(w, r)

	})

}

// func to setup session data
func SetupSession(next http.Handler) http.Handler {
	fmt.Println(sessiongManager.LoadAndSave(next))
	return sessiongManager.LoadAndSave(next)

}

// make settings to the cookie
func NoSurf(next http.Handler) http.Handler {
	noSurfHandler := nosurf.New(next)

	noSurfHandler.SetBaseCookie(http.Cookie{
		Name:     "my-cookie",
		Path:     "/",
		Domain:   "",
		Secure:   false, // Change to 'true' for HTTPS
		HttpOnly: true,
		MaxAge:   3600,
		SameSite: http.SameSiteLaxMode,
	})

	return noSurfHandler
}

func Authenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !helpers.IsAuthenticated(r) {
			AppConfig.Session.Put(r.Context(), "erorr", "you aren't logged in")
			http.Redirect(w, r, "/login", http.StatusSeeOther)

			return
		}
		next.ServeHTTP(w, r)
	})
}
