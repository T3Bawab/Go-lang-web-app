package renders

import (
	"MyWeb/models"
	"MyWeb/pkg/configs"
	"fmt"
	"net/http"
	"text/template"

	"github.com/justinas/nosurf"
)

var (
	tmplCache = make(map[string]*template.Template)
	app       *configs.AppConfig
)

func NewAppconfig(a *configs.AppConfig) {
	app = a
}
func AddCSRFdata(dataPage *models.DataPage, r *http.Request) *models.DataPage {
	dataPage.CSRFToken = nosurf.Token(r)
	if app.Session.Exists(r.Context(), "user_id") {
		dataPage.IsAuthenticated = 1 // 1 meen true
	}
	return dataPage
}

func RenderTemplate(w http.ResponseWriter, r *http.Request, tName string, dataPage *models.DataPage) {
	var (
		tmpl *template.Template
		err  error
	)

	_, inMap := tmplCache[tName]
	if !inMap {
		err = makeTemplateCache(tName)
		if err != nil {
			fmt.Println("( ! ) Error with MakeTemplateCache : \n\n", err)
		}
	}

	tmpl = tmplCache[tName]

	dataPage = AddCSRFdata(dataPage, r)

	err = tmpl.Execute(w, dataPage)

	if err != nil {
		fmt.Println("( ! ) Error with Execute Template :", err)
	}
}

func makeTemplateCache(tName string) error {
	templates := []string{ // here the all templates place and with the name
		fmt.Sprintf("./templates/%s", tName),
		"./templates/base.layout.tmpl",
	}

	tmpl, err := template.ParseFiles(templates...)

	if err != nil {
		return err
	}
	tmplCache[tName] = tmpl

	return nil
}
