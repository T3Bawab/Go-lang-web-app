package dbdriver

import (
	"database/sql"
	"time"

	_ "github.com/jackc/pgx/v4"
	_ "github.com/jackc/pgx/v4/stdlib"
)

// 1 : go get github.com/jackc/pgx/v4

type DataBase struct {
	SQL *sql.DB
}

var dbConn = &DataBase{}

const (
	maxopenDatabaseConns = 20
	maxIdeLDatebaseConns = 10
	maxDatabaseLifetime  = 5 * time.Minute
)

func NewDatabase(dsn string) (*sql.DB, error) {
	db, err := sql.Open("pgx", dsn)

	if err != nil {
		return nil, err
	}

	err = db.Ping()
	if err != nil {
		return nil, err
	}

	return db, nil

}

func Sql_Connect(dsn string) (*DataBase, error) {
	db, err := NewDatabase(dsn)
	if err != nil {
		panic(err)
	}

	db.SetMaxOpenConns(maxopenDatabaseConns)
	db.SetMaxIdleConns(maxIdeLDatebaseConns)
	db.SetConnMaxLifetime(maxDatabaseLifetime)

	dbConn.SQL = db
	return dbConn, nil
}
