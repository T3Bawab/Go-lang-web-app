package dbrepo

import (
	"MyWeb/models"
	"context"
	"errors"
	"time"

	"golang.org/x/crypto/bcrypt"
)

func (m *postgres_DB_Repo) InsertPost(newPost models.Post) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()

	query := `INSERT INTO posts(title , content , user_id ) VALUES($1 ,$2 ,$3)`

	_, err := m.DataBase.ExecContext(ctx, query, newPost.Title,
		newPost.Content, newPost.UserId)

	if err != nil {
		return err
	}
	return nil
}

func (m *postgres_DB_Repo) GetUserById(Id int) (models.User, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()

	query := `SELECT name , email , password , acct_created , last_login , user_type, id FROM users WHERE id = $1`

	rows := m.DataBase.QueryRowContext(ctx, query, Id)

	var u models.User

	err := rows.Scan(
		&u.Name,
		&u.Email,
		&u.Passwrod,
		&u.AcctCreated,
		&u.LastLogin,
		&u.UserType,
		&u.ID,
	)

	if err != nil {
		return u, err
	}
	return u, nil
}

func (m *postgres_DB_Repo) UpdateUser(u models.User) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()

	query := `UPDATE users SET name = $1, email = $2 last_login = $3, user_type = $4 `

	_, err := m.DataBase.ExecContext(ctx, query,
		u.Name, u.Email, time.Now(), u.UserType)

	if err != nil {
		return err
	}
	return nil

}

func (m *postgres_DB_Repo) AuthenticateUser(email, testPass string) (int, string, error) { // returns id , hash pass , error
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()

	var (
		id          int
		hashed_pass string
	)

	query := `SELECT id, password FROM users WHERE email = $1`

	row := m.DataBase.QueryRowContext(ctx, query, email)

	err := row.Scan(&id, &hashed_pass)

	if err != nil {
		return id, "", err
	}

	err = bcrypt.CompareHashAndPassword([]byte(hashed_pass), []byte(testPass))

	if err == bcrypt.ErrMismatchedHashAndPassword {
		return 0, "", errors.New("password is incorrect")
	} else if err != nil {
		return 0, "", err
	}

	return id, hashed_pass, nil
}

func (m *postgres_DB_Repo) GetAnArticle() (int, int, string, string, error) { // returns id , user_id , title , content , error
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)

	defer cancel()

	var (
		id, userId       int
		ATitle, AContent string
	)

	query := `SELECT id , user_id , title , content FROM posts LIMIT 1`

	row := m.DataBase.QueryRowContext(ctx, query)
	err := row.Scan(&id, &userId, &ATitle, &AContent)

	if err != nil {
		return id, userId, "", "", err
	}

	return id, userId, ATitle, AContent, nil
}

func (m *postgres_DB_Repo) Get3AnArticle() (models.ArticleList, error) { // returns id , user_id , title , content , error

	var ArticleList models.ArticleList

	rows, err := m.DataBase.Query("SELECT id , user_id , title , content FROM posts ORDER BY id DESC LIMIT $1", 3)

	if err != nil {
		panic(err)
	}

	defer rows.Close()

	for rows.Next() {
		var id, user_id int
		var title, content string

		err = rows.Scan(&id, &user_id, &title, &content)

		if err != nil {

			panic(err)
		}

		ArticleList.ID = append(ArticleList.ID, id)
		ArticleList.UserId = append(ArticleList.UserId, user_id)
		ArticleList.Title = append(ArticleList.Title, title)
		ArticleList.Content = append(ArticleList.Content, content)

	}

	err = rows.Err()
	if err != nil {
		panic(err)

	}
	return ArticleList, nil
}
