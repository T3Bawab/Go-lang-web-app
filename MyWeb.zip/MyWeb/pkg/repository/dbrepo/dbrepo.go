package dbrepo

import (
	"MyWeb/pkg/configs"
	"MyWeb/pkg/repository"
	"database/sql"
)

type postgres_DB_Repo struct {
	App      *configs.AppConfig
	DataBase *sql.DB
}

func NewPostgresRepo(db_conn *sql.DB, app *configs.AppConfig) repository.DataBaseRepo {
	return &postgres_DB_Repo{
		App:      app,
		DataBase: db_conn,
	}

}
