package repository

import "MyWeb/models"

type DataBaseRepo interface {
	InsertPost(newPost models.Post) error

	AuthenticateUser(email, testPass string) (int, string, error)

	UpdateUser(u models.User) error

	GetUserById(Id int) (models.User, error)

	GetAnArticle() (int, int, string, string, error)

	Get3AnArticle() (models.ArticleList, error)
}
