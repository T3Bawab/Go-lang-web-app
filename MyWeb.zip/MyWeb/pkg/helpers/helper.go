package helpers

import (
	"MyWeb/pkg/configs"
	"log"
	"net/http"
)

var app configs.AppConfig

func ErrorCheck(err error) {
	if err != nil {
		log.Fatal("Erorr :", err)
	}
}

func IsAuthenticated(r *http.Request) bool {
	exists := app.Session.Exists(r.Context(), "user_id")
	return exists
}
