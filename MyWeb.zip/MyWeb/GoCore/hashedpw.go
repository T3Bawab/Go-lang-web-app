package main

import (
	"fmt"

	"golang.org/x/crypto/bcrypt"
)

func main() {
	pw := "32347569"
	hashpw, _ := bcrypt.GenerateFromPassword([]byte(pw), 12)

	fmt.Println(string(hashpw))
}
